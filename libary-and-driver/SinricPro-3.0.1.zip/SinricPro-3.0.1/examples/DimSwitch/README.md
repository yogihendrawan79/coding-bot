# Tutorials

[Dimmable Switch Tutorial using YYAC-3S for ESP32](https://help.sinric.pro/pages/tutorials/dimmable-switch/YYAC-3S)

[Dimmable Switch Tutorial using RobotDyn AC Light Dimmer Module](https://help.sinric.pro/pages/tutorials/dimmable-switch/robotdyn-ac-light-dimmer)
