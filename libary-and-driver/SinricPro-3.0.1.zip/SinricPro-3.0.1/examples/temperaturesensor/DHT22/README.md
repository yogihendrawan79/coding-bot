# Temperature Sensor Example
![Wiring](https://github.com/sinricpro/esp8266-esp32-sdk/blob/master/examples/temperaturesensor/DHT22/DHT22_Wiring.png)
  
D5: connected to DHT22 signal and via 10k resistor to +3.3V
